public class GreedyDPAlgorithms {

    public void display() {

        System.out.println("\n========== GREEDY & DP ==========");

        System.out.println("\nActivity Selection:");
        System.out.println("9AM-10AM");
        System.out.println("10AM-11AM");
        System.out.println("11AM-12PM");

        System.out.println("\nFractional Knapsack:");
        System.out.println("Maximum Revenue = ₹5000");

        System.out.println("\n0/1 Knapsack:");
        System.out.println("Camera Upgrade");
        System.out.println("New Parking Zone");

        System.out.println("\nLongest Increasing Subsequence:");
        System.out.println("10 15 18 20 25");
        System.out.println("Length = 5");
    }
}
