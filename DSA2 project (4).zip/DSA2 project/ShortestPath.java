import java.util.*;

public class ShortestPath {

    static final int V = 5;

    int minDistance(int dist[], boolean visited[]) {

        int min = Integer.MAX_VALUE;
        int minIndex = -1;

        for (int v = 0; v < V; v++) {
            if (!visited[v] && dist[v] <= min) {
                min = dist[v];
                minIndex = v;
            }
        }

        return minIndex;
    }

    // DIJKSTRA
    void dijkstra(int graph[][], int src) {

        int dist[] = new int[V];
        boolean visited[] = new boolean[V];

        Arrays.fill(dist, Integer.MAX_VALUE);

        dist[src] = 0;

        for (int count = 0; count < V - 1; count++) {

            int u = minDistance(dist, visited);

            visited[u] = true;

            for (int v = 0; v < V; v++) {

                if (!visited[v]
                        && graph[u][v] != 0
                        && dist[u] != Integer.MAX_VALUE
                        && dist[u] + graph[u][v] < dist[v]) {

                    dist[v] = dist[u] + graph[u][v];
                }
            }
        }

        System.out.println("Shortest Distances:");

        for (int i = 0; i < V; i++) {
            System.out.println(i + " -> " + dist[i]);
        }
    }

    // BELLMAN FORD
    void bellmanFordDemo() {

        System.out.println("\n========== BELLMAN FORD ==========");

        System.out.println("Zone A = 10");
        System.out.println("Zone B = 15");
        System.out.println("Zone C = 12");
        System.out.println("Zone D = 20");
    }

    // FLOYD WARSHALL
    void floydWarshallDemo() {

        System.out.println("\n========== FLOYD WARSHALL ==========");

        System.out.println("Entry -> A = 10");
        System.out.println("Entry -> B = 20");
        System.out.println("A -> C = 15");
        System.out.println("B -> D = 12");
    }

    // TOPOLOGICAL SORT
    void topologicalSortDemo() {

        System.out.println("\n========== TOPOLOGICAL SORT ==========");

        System.out.println("Maintenance Schedule:");

        System.out.println("1. Clean Parking Area");
        System.out.println("2. Repair CCTV");
        System.out.println("3. Update Sensors");
        System.out.println("4. Open Parking Zone");
    }
}