import java.util.*;

class SlotNode {
    int slotId;
    String status;
    SlotNode left, right;

    SlotNode(int slotId, String status) {
        this.slotId = slotId;
        this.status = status;
        left = right = null;
    }
}

public class ParkingSlotBST {
    SlotNode root;

    SlotNode insert(SlotNode root, int slotId, String status) {
        if (root == null) {
            return new SlotNode(slotId, status);
        }

        if (slotId < root.slotId)
            root.left = insert(root.left, slotId, status);
        else
            root.right = insert(root.right, slotId, status);

        return root;
    }

    void insertSlot(int slotId, String status) {
        root = insert(root, slotId, status);
    }

    void inorder(SlotNode root) {
        if (root != null) {
            inorder(root.left);
            System.out.println("Slot ID: " + root.slotId + " Status: " + root.status);
            inorder(root.right);
        }
    }

    void displaySlots() {
        inorder(root);
    }
}