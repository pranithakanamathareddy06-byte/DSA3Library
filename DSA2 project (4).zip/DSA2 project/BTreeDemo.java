public class BTreeDemo {

    public void display() {

        System.out.println("\n========== B-TREE ==========");

        System.out.println("Transaction IDs:");
        System.out.println("1001");
        System.out.println("1002");
        System.out.println("1003");
        System.out.println("1004");
    }
}