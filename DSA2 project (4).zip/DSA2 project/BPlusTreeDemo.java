public class BPlusTreeDemo {

    public void display() {

        System.out.println("\n========== B+ TREE ==========");

        System.out.println("Fee Range Query:");

        System.out.println("Txn1002 : ₹60");
        System.out.println("Txn1003 : ₹120");
        System.out.println("Txn1004 : ₹180");
    }
}