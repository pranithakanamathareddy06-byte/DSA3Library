class VehicleNode {
    String vehicleNumber;
    int height;
    VehicleNode left, right;

    VehicleNode(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
        height = 1;
    }
}

public class VehicleAVL {

    VehicleNode root;

    int height(VehicleNode n) {
        if (n == null)
            return 0;
        return n.height;
    }

    int getBalance(VehicleNode n) {
        if (n == null)
            return 0;
        return height(n.left) - height(n.right);
    }

    VehicleNode rightRotate(VehicleNode y) {
        VehicleNode x = y.left;
        VehicleNode t2 = x.right;

        x.right = y;
        y.left = t2;

        y.height = Math.max(height(y.left), height(y.right)) + 1;
        x.height = Math.max(height(x.left), height(x.right)) + 1;

        return x;
    }

    VehicleNode leftRotate(VehicleNode x) {
        VehicleNode y = x.right;
        VehicleNode t2 = y.left;

        y.left = x;
        x.right = t2;

        x.height = Math.max(height(x.left), height(x.right)) + 1;
        y.height = Math.max(height(y.left), height(y.right)) + 1;

        return y;
    }

    VehicleNode insert(VehicleNode node, String vehicleNumber) {

        if (node == null)
            return new VehicleNode(vehicleNumber);

        if (vehicleNumber.compareTo(node.vehicleNumber) < 0)
            node.left = insert(node.left, vehicleNumber);
        else
            node.right = insert(node.right, vehicleNumber);

        node.height = 1 + Math.max(height(node.left), height(node.right));

        int balance = getBalance(node);

        if (balance > 1 && vehicleNumber.compareTo(node.left.vehicleNumber) < 0)
            return rightRotate(node);

        if (balance < -1 && vehicleNumber.compareTo(node.right.vehicleNumber) > 0)
            return leftRotate(node);

        if (balance > 1 && vehicleNumber.compareTo(node.left.vehicleNumber) > 0) {
            node.left = leftRotate(node.left);
            return rightRotate(node);
        }

        if (balance < -1 && vehicleNumber.compareTo(node.right.vehicleNumber) < 0) {
            node.right = rightRotate(node.right);
            return leftRotate(node);
        }

        return node;
    }

    void insertVehicle(String vehicleNumber) {
        root = insert(root, vehicleNumber);
    }

    void inorder(VehicleNode root) {
        if (root != null) {
            inorder(root.left);
            System.out.println(root.vehicleNumber);
            inorder(root.right);
        }
    }

    void displayVehicles() {
        inorder(root);
    }
}