public class SortingAlgorithms {

    public void display() {

        System.out.println("\n========== SORTING ==========");

        System.out.println("\nMerge Sort:");
        System.out.println("1001 1003 1005 1008");

        System.out.println("\nQuick Sort:");
        System.out.println("ZoneA 120");
        System.out.println("ZoneB 95");
        System.out.println("ZoneC 80");

        System.out.println("\nHeap Sort:");
        System.out.println("Slot105 150");
        System.out.println("Slot102 120");

        System.out.println("\nRadix Sort:");
        System.out.println("AP39AB1234");
        System.out.println("AP39CD5678");
        System.out.println("AP39EF9999");
    }
}