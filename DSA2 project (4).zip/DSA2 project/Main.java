public class Main {

    public static void main(String[] args) {

        System.out.println("======================================");
        System.out.println("     PARKSMART MANAGEMENT SYSTEM      ");
        System.out.println("======================================");

        // BST MODULE
        System.out.println("\n========== BST PARKING SLOTS ==========");

        ParkingSlotBST bst = new ParkingSlotBST();

        bst.insertSlot(101, "Available");
        bst.insertSlot(102, "Occupied");
        bst.insertSlot(103, "Available");
        bst.insertSlot(104, "Occupied");
        bst.insertSlot(105, "Available");

        System.out.println("\nParking Slot Records:");
        bst.displaySlots();

        // AVL MODULE
        System.out.println("\n========== AVL VEHICLE RECORDS ==========");

        VehicleAVL avl = new VehicleAVL();

        avl.insertVehicle("AP39AB1234");
        avl.insertVehicle("AP39CD5678");
        avl.insertVehicle("AP39EF9999");
        avl.insertVehicle("AP39GH2222");

        System.out.println("\nBalanced Vehicle Entries:");
        avl.displayVehicles();

        // SEGMENT TREE MODULE
        System.out.println("\n========== SEGMENT TREE ANALYTICS ==========");

        int occupancy[] = {10, 15, 20, 25, 30};

        SegmentTree st = new SegmentTree(occupancy);

        System.out.println("\nHourly Parking Occupancy:");
        System.out.println("Hour 1 : 10 Vehicles");
        System.out.println("Hour 2 : 15 Vehicles");
        System.out.println("Hour 3 : 20 Vehicles");
        System.out.println("Hour 4 : 25 Vehicles");
        System.out.println("Hour 5 : 30 Vehicles");

        System.out.println("\nOccupancy From Hour 2 to Hour 4:");
        System.out.println("Total Occupancy = " + st.getOccupancy(1, 3));

        // FENWICK TREE MODULE
        System.out.println("\n========== FENWICK TREE REVENUE ==========");

        FenwickTree ft = new FenwickTree(5);

        ft.update(1, 100);
        ft.update(2, 200);
        ft.update(3, 300);
        ft.update(4, 400);

        System.out.println("\nRevenue Collection:");
        System.out.println("Transaction 1 : 100");
        System.out.println("Transaction 2 : 200");
        System.out.println("Transaction 3 : 300");
        System.out.println("Transaction 4 : 400");

        System.out.println("\nTotal Revenue From Transaction 1 to 4:");
        System.out.println("Revenue = " + ft.getRevenue(1, 4));

        // GRAPH MODULE
        System.out.println("\n========== PARKING GRAPH NETWORK ==========");

        ParkingGraph graph = new ParkingGraph(5);

        graph.addEdge(0, 1);
        graph.addEdge(0, 2);
        graph.addEdge(1, 3);
        graph.addEdge(2, 4);

        System.out.println("\nParking Zone Connections:");
        System.out.println("0 --> 1");
        System.out.println("0 --> 2");
        System.out.println("1 --> 3");
        System.out.println("2 --> 4");

        System.out.println("\nBFS Traversal (Nearest Slot Search):");
        graph.BFS(0);

        System.out.println("\n\nDFS Traversal (Connectivity Analysis):");
        graph.DFS(0);

        // DIJKSTRA MODULE
        System.out.println("\n\n========== DIJKSTRA SHORTEST PATH ==========");

        int graphMatrix[][] = {
                {0, 10, 0, 30, 100},
                {10, 0, 50, 0, 0},
                {0, 50, 0, 20, 10},
                {30, 0, 20, 0, 60},
                {100, 0, 10, 60, 0}
        };

        System.out.println("\nParking Route Cost Matrix:");
        System.out.println("Zones Connected With Distance Costs");

        ShortestPath sp = new ShortestPath();

        System.out.println("\nShortest Distance From Entry Zone:");
        sp.dijkstra(graphMatrix, 0);
        sp.bellmanFordDemo();
        sp.floydWarshallDemo();
        sp.topologicalSortDemo();

        // MST MODULE
        System.out.println("\n========== MINIMUM SPANNING TREE ==========");

        MSTAlgorithms mst = new MSTAlgorithms();

        System.out.println("\nOptimal Parking Network Layout:");
        mst.primMST(graphMatrix);
BTreeDemo bt = new BTreeDemo();
bt.display();

BPlusTreeDemo bpt = new BPlusTreeDemo();
bpt.display();

SortingAlgorithms sort = new SortingAlgorithms();
sort.display();

GreedyDPAlgorithms dp = new GreedyDPAlgorithms();
dp.display();
        System.out.println("\n======================================");
        System.out.println("   PROJECT EXECUTION COMPLETED");
        System.out.println("======================================");
    }
}